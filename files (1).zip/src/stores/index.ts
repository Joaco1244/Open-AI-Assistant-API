import Redis from "ioredis";

export type SessionRecord = {
  state?: any;
  lastActivityAt?: number;
};

export interface SessionStore {
  get(sessionId: string): Promise<SessionRecord | null>;
  save(sessionId: string, record: SessionRecord): Promise<void>;
  delete?(sessionId: string): Promise<void>;
}

/**
 * In-memory store (suitable for single-instance or dev).
 * For production across multiple instances use Redis store.
 */
class MemoryStore implements SessionStore {
  private map = new Map<string, SessionRecord>();
  async get(sessionId: string) {
    return this.map.get(sessionId) ?? null;
  }
  async save(sessionId: string, record: SessionRecord) {
    this.map.set(sessionId, record);
  }
  async delete(sessionId: string) {
    this.map.delete(sessionId);
  }
}

/**
 * Redis-backed store
 */
class RedisStore implements SessionStore {
  private client: Redis;
  private prefix = "vf:session:";

  constructor(redisUrl: string) {
    this.client = new Redis(redisUrl);
  }

  async get(sessionId: string) {
    const raw = await this.client.get(this.prefix + sessionId);
    if (!raw) return null;
    return JSON.parse(raw) as SessionRecord;
  }
  async save(sessionId: string, record: SessionRecord) {
    await this.client.set(this.prefix + sessionId, JSON.stringify(record), "EX", 60 * 60 * 24 * 7); // 7 days TTL
  }
  async delete(sessionId: string) {
    await this.client.del(this.prefix + sessionId);
  }
}

let storeInstance: SessionStore | null = null;

export function getSessionStore(): SessionStore {
  if (storeInstance) return storeInstance;

  const storeType = process.env.SESSION_STORE || "memory";
  if (storeType === "redis" && process.env.REDIS_URL) {
    storeInstance = new RedisStore(process.env.REDIS_URL);
  } else {
    storeInstance = new MemoryStore();
  }
  return storeInstance;
}